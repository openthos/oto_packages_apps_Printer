DEVICE_URI=hp:/usb/HP_LaserJet_Professional_P1108?serial=000000000Q8DG5Z7PR1a
PRINTER=fasffaafsfsa
DEVICE_URI1=${DEVICE_URI#*?serial=}
DEVICE_URI='hp:/usb/'$PRINTER'?serial='$DEVICE_URI1
echo $DEVICE_URI
