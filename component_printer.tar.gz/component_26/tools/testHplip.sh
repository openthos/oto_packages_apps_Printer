strace -f cupsd -f &> 111
