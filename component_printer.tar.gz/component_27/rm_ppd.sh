#!/bin/bash
# Copyright (c) 2016, Taocr
# Author: Tao<taocr2005@163.com>
# Created: 2016-07-28
# Description:
filename="$1"
while read line
do
	rm -v $line
done < "$filename"
