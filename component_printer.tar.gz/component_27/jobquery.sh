lpq -a && lpstat -l -o
