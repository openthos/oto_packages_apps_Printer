#!/bin/bash
# Author: Tao<taocr2005@163.com>
# Created: 2016-06-19
# Description:
#This script is used to hold print task or release print task

for((i=1;i<"$#";i++))
do
#	eval echo "$""$i"
	eval lp -i "$""$i" -H "$""$#"
done
