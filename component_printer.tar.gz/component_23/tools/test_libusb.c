#include <stdio.h>
#include <libusb-1.0/libusb.h>

int main()
{
	libusb_device **list;
	int r = libusb_init(NULL);
	if( r < 0 ){
		printf("init error\n");
		return 1;
	}
	int numdevs = libusb_get_device_list(NULL, &list);
	printf("usb number is %d\n", numdevs);
	return 0;
}
